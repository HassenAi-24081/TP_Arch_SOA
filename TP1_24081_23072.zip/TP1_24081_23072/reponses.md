# TP1 — SOAP et WSDL : réponses

Binôme : Nom1 / Nom2

---

## Partie A — Code-first

### Étape 1 — Créer et lancer le service

**1. Quelle annotation fait de `EmpruntService` un service web ? Laquelle fait de `LivreIndisponibleException` une erreur déclarée dans le contrat ?**

`@WebService` sur `EmpruntService`. `@WebFault` sur `LivreIndisponibleException` : l'erreur apparaît alors comme un `wsdl:fault` dans le `portType`.

**2. Pourquoi les classes de données doivent-elles avoir un constructeur vide ?**

JAXB crée les objets par réflexion quand il désérialise le XML reçu, puis remplit les champs. Sans constructeur sans argument, il ne peut pas instancier la classe.

---

### Étape 2 — Lire le WSDL généré

**1. Quelle est l'URL du service ? Quelles sont les deux opérations et leurs messages ?**

L'URL est `http://localhost:8080/bib/EmpruntService` (élément `soap:address` dans `wsdl:service`).

- `emprunterLivre` : message d'entrée `emprunterLivre`, message de sortie `emprunterLivreResponse`, plus la fault `LivreIndisponible`.
- `rendreLivre` : message d'entrée `rendreLivre`, message de sortie `rendreLivreResponse`.

**2. Quel style et quel use le binding déclare-t-il ? SOAP 1.1 ou 1.2 ?**

Style `document`, use `literal`. C'est du **SOAP 1.1** : le binding utilise le namespace `http://schemas.xmlsoap.org/wsdl/soap/` (le 1.2 serait `.../wsdl/soap12/`).

**3. Quel type XSD pour `isbn` et `dateRetour` ? La règle de format de l'ISBN apparaît-elle ?**

Les deux sont de type `xs:string`. La règle de format de l'ISBN n'apparaît pas : elle n'existe que dans le code Java (une regex), pas dans le contrat.

**4. Dans la requête SoapUI, `idAdherent` et `isbn` portent-ils un préfixe d'espace de noms ?**

Non. Seul l'élément de l'opération (`emprunterLivre`) est préfixé. Les paramètres sont non qualifiés : `<idAdherent>` et `<isbn>`.

**5. Où voit-on HTTP, XML, SOAP dans l'onglet Raw ? Quel rôle pour chacun, et pour le WSDL ?**

- **HTTP** : la ligne `POST /bib/EmpruntService HTTP/1.1` et les en-têtes (`Content-Type`, `SOAPAction`). Il transporte le message et fournit les codes de statut.
- **XML** : le corps du message. C'est la syntaxe commune (balises, espaces de noms, schémas).
- **SOAP** : la structure `Envelope` / `Header` / `Body`. Elle définit l'enveloppe, les en-têtes extensibles et le modèle de Fault.
- **WSDL** : il n'est pas sur le fil. C'est le contrat qui décrit l'adresse, les opérations, les messages et leur emballage. SoapUI s'en sert pour générer la requête.

---

### Étape 3 — Envoyer des messages SOAP

**1. Pourquoi POST, même pour lire une information ?**

SOAP sur HTTP place l'enveloppe dans le corps de la requête, et GET n'a pas de corps. De plus, SOAP est un appel de procédure distante : une seule URL, et c'est l'opération dans le Body qui choisit l'action.

**2. Le bloc `jeton` du Header a-t-il empêché le traitement ?**

Non. Sans `mustUnderstand="1"`, un bloc d'en-tête est facultatif : un récepteur qui ne le connaît pas l'ignore.

**3. Que répond le service au message SOAP 1.2 ?**

Une Fault `VersionMismatch` (HTTP 500). Le binding lu à l'étape 2 est SOAP 1.1, il attend donc le namespace `http://schemas.xmlsoap.org/soap/envelope/`. Le namespace 1.2 (`http://www.w3.org/2003/05/soap-envelope`) n'est pas reconnu.

**4. Les cinq erreurs du dernier message et leur correction.**

1. **Casse de `Envelope`** : l'ouverture est `<soap:envelope>` mais la fermeture est `</soap:Envelope>`. Le XML est sensible à la casse. Correction : `<soap:Envelope>`. Le serveur la détecte (XML mal formé).
2. **Mauvais namespace** : `bib` vaut `http://supnum.mr/bibliotheque` au lieu de `http://supnum.mr/bib`. Correction : `http://supnum.mr/bib`. Le serveur la détecte (opération inconnue, Fault).
3. **Mauvais nom de paramètre** : `<bib:numero>` au lieu de `<numeroEmprunt>` (non qualifié). Le serveur ne la détecte pas avant l'étape 4 : l'élément inconnu est ignoré, `numeroEmprunt` vaut `null` et la première version renvoie `0`. Depuis l'étape 4, on obtient une Fault Client.
4. **Balise fermante sans préfixe** : `</rendreLivre>` ne ferme pas `<bib:rendreLivre>`. Correction : `</bib:rendreLivre>`. Le serveur la détecte (XML mal formé).
5. **Header après le Body** : le Header doit être le premier enfant de l'Envelope. Correction : le placer avant le Body. Le serveur ne la détecte pas : le parseur de Metro est tolérant et le Header n'a de toute façon aucun effet.

Les erreurs 1 et 4 rendent le XML mal formé et masquent les autres tant qu'elles ne sont pas corrigées. Les erreurs 3 et 5 passent sans erreur parce que le serveur ignore ce qu'il ne connaît pas (élément non déclaré, Header non obligatoire) et ne valide pas le message contre le schéma.

Message corrigé :

```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:bib="http://supnum.mr/bib">
  <soap:Header><bib:jeton>abc123</bib:jeton></soap:Header>
  <soap:Body>
    <bib:rendreLivre>
      <numeroEmprunt>E-2026-0812</numeroEmprunt>
    </bib:rendreLivre>
  </soap:Body>
</soap:Envelope>
```

---

### Étape 4 — Provoquer et construire des Faults

**1. Cas 1 et 2 : quels `faultcode`, `faultstring` et code HTTP ?**

- Cas 1 (ISBN `978-2-10`) : `faultcode` = `S:Client`, `faultstring` = « ISBN mal formé : 978-2-10 », HTTP 500.
- Cas 2 (ISBN `978-2-10-074444-4`) : `faultcode` = `S:Server`, `faultstring` = « Livre indisponible », HTTP 500.

En SOAP 1.1, toute Fault est renvoyée avec le code HTTP 500.

**2. Dans le cas 2, que contient `<detail>` ? Où sa structure est-elle décrite dans le WSDL ?**

`<detail>` contient l'élément `LivreIndisponible` (namespace `http://supnum.mr/bib`) avec `<isbn>978-2-10-074444-4</isbn>` et `<retourPrevu>2026-12-02</retourPrevu>`.

Sa structure se retrouve en suivant la chaîne du WSDL : `wsdl:fault` de l'opération dans le `portType`, puis le `wsdl:message` `LivreIndisponible`, puis son `wsdl:part` (un élément), puis la définition de cet élément dans le schéma XSD (`?xsd=1`). Le binding le reprend avec `soap:fault`.

**3. Quel code JAX-WS a-t-il choisi pour le livre indisponible ? Client ou Server ? Qu'auriez-vous choisi ?**

JAX-WS a choisi `Server`. Ce n'est pas très juste : rien n'est cassé côté serveur, c'est la demande qui ne peut pas être satisfaite (le livre est déjà sorti). J'aurais choisi `Client`, et gardé `Server` pour les pannes d'infrastructure.

**4. Que se passe-t-il avec `mustUnderstand="1"` ? Et avec `"0"` ?**

- Avec `"1"` : le service ne comprend pas `jeton`, il doit refuser le message avec une Fault `MustUnderstand` (HTTP 500), sans exécuter l'opération.
- Avec `"0"` (ou si l'attribut est absent) : l'en-tête est facultatif, il est ignoré et la requête est traitée normalement.

**5. Quelle différence entre votre Fault 1.2 et les Faults 1.1 reçues ?**

- `faultcode` devient `soap:Code/soap:Value`, avec les valeurs `Sender` et `Receiver` à la place de `Client` et `Server`.
- `faultstring` devient `soap:Reason/soap:Text`, avec l'attribut `xml:lang` obligatoire.
- `detail` (non qualifié) devient `soap:Detail`, dans le namespace SOAP.
- `faultactor` est remplacé par `soap:Node` et `soap:Role`.
- Côté HTTP, SOAP 1.2 utilise 400 pour Sender et 500 pour Receiver, alors que SOAP 1.1 utilise toujours 500.

---

## Partie B — Contract-first

### Étape 5 — Générer le code depuis le WSDL

**1. Retrouvez l'opération, son message de fault et l'action SOAP.**

- Opération : `emprunterLivre`.
- Message de fault : `LivreIndisponibleFault` (référencé par `wsdl:fault name="LivreIndisponible"`, qui contient l'élément `bib:LivreIndisponible`).
- Action SOAP : `http://supnum.mr/bib/emprunterLivre` (attribut `soapAction` de `soap:operation`).

**2. Quelle est la signature de `emprunterLivre` dans `EmpruntPortType` ?**

```java
EmpruntType emprunterLivre(String idAdherent, String isbn) throws LivreIndisponibleFault
```

`IsbnType` est une restriction de `xs:string`, il devient donc un `String`.

**3. Quel type Java pour `dateRetour` ? Comparaison avec la partie A.**

`XMLGregorianCalendar`, qui correspond à `xs:date`. En partie A, le type était simplement `String` : le contrat perdait l'information qu'il s'agit d'une date.

**4. Quel est le nom de la classe d'exception, et d'où vient-il ?**

`LivreIndisponibleFault`. Ce nom vient du nom du `wsdl:message` `LivreIndisponibleFault`. La classe `LivreIndisponible`, elle, vient de l'élément XSD et sert de `faultInfo`.

---

### Étape 6 — Implémenter et comparer

**1. Le WSDL publié est-il celui fourni ? Contient-il le motif de l'ISBN et `xs:date` ?**

Oui. Grâce à `wsdlLocation`, Metro publie le WSDL fourni (seule l'adresse du `soap:address` est ajustée). Il contient bien le motif de `IsbnType` et le type `xs:date`.

**2. Avez-vous dû modifier `01-emprunter.xml` ? Pourquoi ?**

Oui, pour deux raisons :

- Les paramètres doivent être qualifiés : `<bib:idAdherent>` et `<bib:isbn>`, car le schéma a `elementFormDefault="qualified"` (voir `xml/cf-01-emprunter.xml`). Sinon `isbn` vaut `null` et le service échoue.
- La `SOAPAction` doit être celle du WSDL (`"http://supnum.mr/bib/emprunterLivre"`) au lieu de `""`.

**3. Sans `@SchemaValidation`, l'ISBN `978-2-10` est-il refusé ? Et avec ? Quelle Fault ?**

- Sans `@SchemaValidation` : non, il n'est pas refusé. Le message n'est pas validé contre le schéma, le motif n'est qu'une déclaration, et l'implémentation renvoie un emprunt.
- Avec `@SchemaValidation` : il est refusé avant d'atteindre le code, par une Fault `S:Client` dont le `faultstring` indique que la valeur ne respecte pas le motif de `IsbnType`.

**4. Sans `wsdlLocation`, qu'est-ce qui change dans le WSDL publié ?**

Metro régénère le WSDL à partir des annotations : ce n'est plus le contrat d'origine. Le motif de l'ISBN disparaît (le type devient `xs:string`), les noms (portType, binding, messages) peuvent différer, et le schéma est externalisé dans `?xsd=1`.

---

## Conclusion — Choisir et rendre

**1. Deux différences entre le WSDL de la partie A et celui de la partie B.**

- **Types** : en A, `isbn` et `dateRetour` sont des `xs:string`. En B, `isbn` est un `IsbnType` avec motif et `dateRetour` est un `xs:date`.
- **Espaces de noms** : en A, les paramètres sont non qualifiés. En B, ils sont qualifiés (`elementFormDefault="qualified"`).

**2. Si on renomme le champ `dateRetour` dans le code, quel projet voit son contrat changer ? Quel risque ?**

Le projet **code-first** : son WSDL est régénéré à chaque démarrage à partir du code, donc l'élément XML prend le nouveau nom. En contract-first, le WSDL est la source : renommer dans le code ne le change pas.

Le risque est de casser les clients existants sans prévenir. L'ancien élément est ignoré, le nouveau est absent, et rien ne signale le problème côté serveur puisque tout compile.

**3. Quelle approche pour le service Paiement ? Pour un prototype interne de deux jours ?**

- **Paiement** (appelé par Scolarité en .NET, Bibliothèque en PHP, le portail en Node.js) : **contract-first**. Le WSDL/XSD est un contrat neutre, partagé entre équipes et langages, versionnable et validable. Chaque équipe génère son client depuis la même source.
- **Prototype interne de deux jours** : **code-first**. C'est plus rapide et il n'y a qu'un seul consommateur. On fige le WSDL généré avant la mise en production.
